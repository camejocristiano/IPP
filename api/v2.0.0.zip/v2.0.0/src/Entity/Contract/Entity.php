<?php
namespace src\Entity\Contract;

interface Entity
{

}